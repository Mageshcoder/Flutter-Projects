package com.example.app_news

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
