package com.example.app_designs

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
